# Unblock Instagram India 🇮🇳

This project helps users in India unblock Instagram easily. It auto-detects geo, supports Hindi/Русский language, and offers access via Telegram bot.

## Deploy with Vercel
1. Go to https://vercel.com/import
2. Upload this zip archive or link a GitHub repo
3. Done!